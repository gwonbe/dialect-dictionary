var $setRows = $('#setRows');

$setRows.submit(function (e) {
	
	e.preventDefault();
	
	// 테이블 정보 가져오기
	
	var rowPerPage = 10;
	var $table = $('#search_table');
	var $tr = $($table).find('tbody tr');
	var rowTotals = $tr.length;
	var pageTotal = Math.ceil(rowTotals/ rowPerPage);
	
	// 남는 tr에 none_tr 클래스 삽입하기
	
	$tr.addClass('none_tr').slice(0, rowPerPage).removeClass('none_tr');
	
	// 기존 페이지 링크 div를 삭제하고 새로 삽입하기
	
	$('#nav').remove();
	$table.after('<div id="nav">');
	
	// 페이지 링크 div에 번호 매겨서 삽입하기
	
	var i = 0;
	for (; i < pageTotal; i++) {
		$('<a href="#"></a>').attr('rel', i).html(i + 1).appendTo('#nav');
	}
	
	// 페이지 링크 div에서 페이지 링크 가져오기

	var $pagingLink = $('#nav a');
	
	// 페이지 링크를 클릭했을 경우
	
	$pagingLink.on('click', function (evt) {
		
		evt.preventDefault();
		
		var $this = $(this);
		
		if($this.hasClass('active')){
			return;
		}
		
		$pagingLink.removeClass('active');
		$this.addClass('active');
		
		var currPage = $this.attr('rel');
		var trOfStart = currPage * rowPerPage;
		var trOfEnd = trOfStart + rowPerPage;
		$tr.css('opacity', '0.0').addClass('none_tr').slice(trOfStart, trOfEnd).removeClass('none_tr').animate({opacity: 1}, 300);
		
	});
	
	// 페이지 링크 삽입하기
	
	$pagingLink.filter(':first').addClass('active');

});

$setRows.submit();
