const submit = document.getElementById('submitButton');

const userID = document.getElementById('userID');
const userPassWord = document.getElementById('userPassWord');
const userNickName = document.getElementById('userNickName');
const userEmail = document.getElementById('userEmail');

const tdCheckID = document.getElementById("td_checkID");
const tdCheckPassWord = document.getElementById("td_checkPassWord");
const tdCheckNickName = document.getElementById("td_checkNickName");
const tdCheckEmail = document.getElementById("td_checkEmail");


function checkID(obj){
	data = obj.value;
	if( (data==null) || (data=="") || (data.indexOf(" ")==true) || (data.indexOf(",")==true) ||  (data.length<3) ){
		tdCheckID.innerHTML = "X";
	}
	else{
		tdCheckID.innerHTML = "O";
	}
}
function checkPassWord(obj){
	data = obj.value;
	if( (data==null) || (data=="") || (data.indexOf(" ")==true) || (data.indexOf(",")==true) ||  (data.length<3) ){
		tdCheckPassWord.innerHTML = "X";
	}
	else{
		tdCheckPassWord.innerHTML = "O";
	}
}
function checkNickName(obj){
	data = obj.value;
	if( (data==null) || (data=="") || (data.indexOf(" ")==true) || (data.indexOf(",")==true) ||  (data.length<3) ){
		tdCheckNickName.innerHTML = "X";
	}
	else{
		tdCheckNickName.innerHTML = "O";
	}
}
function checkEmail(obj){
	data = obj.value;
	if( (data==null) || (data=="") || (data.indexOf(" ")==true) || (data.indexOf(",")==true) || (data.indexOf("@")==false) || (data.indexOf(".")==false) || (data.length<5) ){
		tdCheckEmail.innerHTML = "X";
	}
	else{
		tdCheckEmail.innerHTML = "O";
	}
}

