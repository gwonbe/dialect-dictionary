package javabean;

import javabean.DialectBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DialectDBCP {
	
	// 필드
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private DataSource ds = null;
	
	// 생성자 : JDBC 드라이버 로드
	public DialectDBCP() {
		try {
			InitialContext ctx = new InitialContext();
		    ds = (DataSource) ctx.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 메소드 : 데이터베이스 연결 및 해제
	public void dbConnect() { 
		try {
		    con = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void dbDisconnect() {
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if(con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 메소드 : 아이디로 방언 레코드 가져오기
	public DialectBean getDialect(int id) {
		dbConnect();
		String sql = "select * from dialect where dialectID=?";
		DialectBean dialect = new DialectBean();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();			
			rs.next();
			dialect.setDialectID(rs.getInt("dialectID"));
			dialect.setDialectDialect(rs.getString("dialectDialect"));
			dialect.setDialectBigArea(rs.getString("dialectBigArea"));
			dialect.setDialectSmallArea(rs.getString("dialectSmallArea"));
			dialect.setDialectMean(rs.getString("dialectMean"));
			dialect.setDialectSentence(rs.getString("dialectSentence"));
			dialect.setDialectUser(rs.getString("dialectUser"));
			rs.close();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			dbDisconnect();
		}
		return dialect;
	}
	
}
