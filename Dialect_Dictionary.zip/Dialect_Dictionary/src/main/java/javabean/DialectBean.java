package javabean;

public class DialectBean {
	
	// 필드
	
	int dialectID;
	String dialectDialect;
	String dialectBigArea;
	String dialectSmallArea;
	String dialectMean;
	String dialectSentence;
	String dialectUser;
	
	// getter & setter
	
	public int getDialectID() {
		return dialectID;
	}
	public void setDialectID(int dialectID) {
		this.dialectID = dialectID;
	}
	public String getDialectDialect() {
		return dialectDialect;
	}
	public void setDialectDialect(String dialectDialect) {
		this.dialectDialect = dialectDialect;
	}
	public String getDialectBigArea() {
		return dialectBigArea;
	}
	public void setDialectBigArea(String dialectBigArea) {
		this.dialectBigArea = dialectBigArea;
	}
	public String getDialectSmallArea() {
		return dialectSmallArea;
	}
	public void setDialectSmallArea(String dialectSmallArea) {
		this.dialectSmallArea = dialectSmallArea;
	}
	public String getDialectMean() {
		return dialectMean;
	}
	public void setDialectMean(String dialectMean) {
		this.dialectMean = dialectMean;
	}
	public String getDialectSentence() {
		return dialectSentence;
	}
	public void setDialectSentence(String dialectSentence) {
		this.dialectSentence = dialectSentence;
	}
	public String getDialectUser() {
		return dialectUser;
	}
	public void setDialectUser(String dialectUser) {
		this.dialectUser = dialectUser;
	}
	
}
