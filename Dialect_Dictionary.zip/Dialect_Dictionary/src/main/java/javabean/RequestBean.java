package javabean;

public class RequestBean {
	
	// 필드
	
	int requestID;
	int requestDialectID;
	String requestDialect;
	String requestBigArea;
	String requestSmallArea;
	String requestMean;
	String requestSentence;
	String requestReason;
	String requestUser;
	String requestSeparation;
	
	// getter & setter
	
	public int getRequestID() {
		return requestID;
	}
	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}
	public int getRequestDialectID() {
		return requestDialectID;
	}
	public void setRequestDialectID(int requestDialectID) {
		this.requestDialectID = requestDialectID;
	}
	public String getRequestDialect() {
		return requestDialect;
	}
	public void setRequestDialect(String requestDialect) {
		this.requestDialect = requestDialect;
	}
	public String getRequestBigArea() {
		return requestBigArea;
	}
	public void setRequestBigArea(String requestBigArea) {
		this.requestBigArea = requestBigArea;
	}
	public String getRequestSmallArea() {
		return requestSmallArea;
	}
	public void setRequestSmallArea(String requestSmallArea) {
		this.requestSmallArea = requestSmallArea;
	}
	public String getRequestMean() {
		return requestMean;
	}
	public void setRequestMean(String requestMean) {
		this.requestMean = requestMean;
	}
	public String getRequestSentence() {
		return requestSentence;
	}
	public void setRequestSentence(String requestSentence) {
		this.requestSentence = requestSentence;
	}
	public String getRequestReason() {
		return requestReason;
	}
	public void setRequestReason(String requestReason) {
		this.requestReason = requestReason;
	}
	public String getRequestUser() {
		return requestUser;
	}
	public void setRequestUser(String requestUser) {
		this.requestUser = requestUser;
	}
	public String getRequestSeparation() {
		return requestSeparation;
	}
	public void setRequestSeparation(String requestSeparation) {
		this.requestSeparation = requestSeparation;
	}
	
}
