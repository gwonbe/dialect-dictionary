package javabean;

import javabean.RequestBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class RequestDBCP {
	
	// 필드
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private DataSource ds = null;
	
	// 생성자 : JDBC 드라이버 로드
	public RequestDBCP() {
		try {
			InitialContext ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	// 메소드 : 데이터베이스 연결 및 해제
	public void dbConnect() { 
		try {
			con = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void dbDisconnect() {
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if(con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 메소드 : 아이디로 요청 레코드 가져오기
	public RequestBean getRequest(int id) {
		dbConnect();
		String sql = "select * from request where requestID=?";
		RequestBean request = new RequestBean();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();			
			rs.next();
			request.setRequestID(rs.getInt("requestID"));
			request.setRequestDialectID(rs.getInt("requestDialectID"));
			request.setRequestDialect(rs.getString("requestDialect"));
			request.setRequestBigArea(rs.getString("requestBigArea"));
			request.setRequestSmallArea(rs.getString("requestSmallArea"));
			request.setRequestMean(rs.getString("requestMean"));
			request.setRequestSentence(rs.getString("requestSentence"));
			request.setRequestReason(rs.getString("requestReason"));
			request.setRequestUser(rs.getString("requestUser"));
			request.setRequestSeparation(rs.getString("requestSeparation"));
			rs.close();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			dbDisconnect();
		}
		return request;
	}
	
	// 메소드 : 아이디로 레코드 삭제하기
	public void removeRequest(int id) {
		dbConnect();
		String sql = "delete from request where requestID=?";
		try{
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			dbDisconnect();
		}
	}
	
}
